package com.example.recipe.exception;

public class CustomException extends RuntimeException {

    // Constructor to initialize the exception with a custom message
    public CustomException(String message) {
        super(message);
    }

    // Constructor to initialize the exception with a message and a cause
    public CustomException(String message, Throwable cause) {
        super(message, cause);
    }
}
