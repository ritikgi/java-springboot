package com.example.recipe.controller;

import com.example.recipe.model.Recipe;
import com.example.recipe.service.RecipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.client.RestTemplate;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/recipes")


public class RecipeController {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RecipeService recipeService;

    @PostMapping("/load")
    public ResponseEntity<String> loadRecipes() {
        // Use the custom RestTemplate for making the external API call
        ResponseEntity<Recipe[]> response = restTemplate.getForEntity("https://dummyjson.com/recipes", Recipe[].class);

        // Save the recipes in the H2 database
        recipeService.loadRecipes(Arrays.asList(response.getBody()));
        return ResponseEntity.ok("Recipes loaded successfully");
    }

    @GetMapping("/search")
    public List<Recipe> searchRecipes(@RequestParam String query) {
        return recipeService.searchRecipes(query);
    }

    @GetMapping("/{id}")
    public Recipe getRecipe(@PathVariable Long id) {
        return recipeService.getRecipeById(id);
    }
}
