package com.example.recipe.controller;

import com.example.recipe.model.Recipe;
import com.example.recipe.model.RecipeResponse;
import com.example.recipe.service.RecipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/api/recipes")


public class RecipeController {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RecipeService recipeService;

    @PostMapping("/load")
    public ResponseEntity<String> loadRecipes() {
        // Use the RestTemplate to call the external API
        RestTemplate restTemplate = new RestTemplate();

        // Call the external API and deserialize the response into RecipeResponse
        ResponseEntity<RecipeResponse> response = restTemplate.getForEntity("https://dummyjson.com/recipes", RecipeResponse.class);

        // Ensure the response is not null and contains recipes
        if (response.getBody() != null && response.getBody().getRecipes() != null) {
            // Get the list of recipes from the response body
            List<Recipe> recipes = response.getBody().getRecipes();

            // Pass the list of recipes to the service for saving in the database
            recipeService.loadRecipes(recipes);
        }
        return ResponseEntity.ok("Recipes loaded successfully");
    }

    @GetMapping("/search")
    public List<Recipe> searchRecipes(@RequestParam String query) {
        return recipeService.searchRecipes(query);
    }

    @GetMapping("/{id}")
    public Recipe getRecipe(@PathVariable Long id) {
        return recipeService.getRecipeById(id);
    }
}
