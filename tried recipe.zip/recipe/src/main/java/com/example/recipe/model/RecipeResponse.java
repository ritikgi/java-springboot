package com.example.recipe.model;


import lombok.Data;
import java.util.List;

@Data
public class RecipeResponse {
    private List<Recipe> recipes;  // This will hold the list of recipes returned by the external API.
}