package com.example.recipe.service;


import com.example.recipe.model.Recipe;
import com.example.recipe.model.RecipeResponse;
import com.example.recipe.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import java.util.List;
import com.example.recipe.exception.CustomException; // Import the custom exception
import org.springframework.transaction.annotation.Transactional;



@Service
public class RecipeService {
    @Autowired
    private RecipeRepository recipeRepository;

    // Ensure this method accepts a List<Recipe>
    public void loadRecipes(List<Recipe> recipes) {
        // Save the list of recipes to the database
        recipeRepository.saveAll(recipes);
    }

    public List<Recipe> searchRecipes(String query) {
        return recipeRepository.searchByNameOrCuisine(query);
    }

    public Recipe getRecipeById(Long id) {
        return recipeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));
    }
    @Transactional  // Ensure the method is wrapped in a transaction
    public void updateRecipe(Recipe recipe) {
        recipeRepository.save(recipe);  // This will update the entity or insert it
    }
}