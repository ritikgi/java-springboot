package com.example.recipe.service;


import com.example.recipe.model.Recipe;
import com.example.recipe.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecipeService {
    @Autowired
    private RecipeRepository recipeRepository;

    public void loadRecipes(List<Recipe> recipes) {
        recipeRepository.saveAll(recipes);
    }

    public List<Recipe> searchRecipes(String query) {
        return recipeRepository.searchByNameOrCuisine(query);
    }

    public Recipe getRecipeById(Long id) {
        return recipeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));
    }
}